This challenge ships with source (coffin.c) and a stub (flag_stub.c). The stub returns a placeholder flag so you can compile the program and test your exploit locally.
A compiled release binary is also available; it contains the real flag. Do not expect to find the real flag in the source files.
