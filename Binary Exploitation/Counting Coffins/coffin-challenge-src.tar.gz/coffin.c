#include <stdio.h>
#include <string.h>
#include <unistd.h>

// get_flag is provided by a separate module (stub for players, real for release)
const char* get_flag(void);

struct user {
    char name[32];
    unsigned char is_admin;
} user;

int main(){
    setbuf(stdout, NULL);
    puts("Register name (max 32 chars):");
    read(0, user.name, 33);

    if(user.is_admin == 1){
        const char *flag = get_flag();
        printf("Flag: %s\n", flag);
    } else {
        puts("Registration complete. You are a guest.");
    }
    return 0;
}
