const char* get_flag(void){
    return "flag{SECRET_NOT_IN_SOURCE}";
}
